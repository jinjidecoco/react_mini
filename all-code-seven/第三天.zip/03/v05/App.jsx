import React from './core/React.js';
const App = React.createElement("div", { id: "app" }, "hi- ", "mini-react");

export default App