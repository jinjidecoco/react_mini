import React from "./core/React.js";
const App = <div>hi-mini-react</div>;

// function App() {
//   return <div>hi-mini-react</div>;
// }

export default App;
