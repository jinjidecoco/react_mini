import React from './core/React.js';
import ReactDOM from "./core/ReactDom.js";
import App from "./App.jsx";

ReactDOM.createRoot(document.querySelector("#root")).render(App);