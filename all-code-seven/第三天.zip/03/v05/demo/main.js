const el = document.createElement("div");

el.innerText = "heihei";

document.body.append(el);

let i = 0;
while (i < 10000000000) {
  i++;
}
